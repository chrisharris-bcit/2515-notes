from flask import Flask

from .programs import routes as programs
from .services import routes as services

# Flask recommends using a factory function (called create_app or make_app)
def create_app(): # Flask will automatically call this function
    app = Flask(__name__)

    # Each 'module', section of the app (programs, services) is going to be a Flask 'Blueprint', which we register (i.e. attach to the app instance)
    app.register_blueprint(services.services_bp)
    app.register_blueprint(programs.programs_bp)

    return app
from flask import Blueprint

services_bp = Blueprint("services", __name__, url_prefix="/services")
# creates endpoints under http://localhost:5000/services

@services_bp.route('/aid')
def aid():
    return "Financial Aid"

@services_bp.route('/wellness')
def wellness():
    return "Health and Wellness"
Steps 

Create a new folder

Inside the folder, run:
    uv init 
    uv add flask
    activate your virtual env

Inside the folder, 
    delete main.py

    create an app/ folder

        inside app/

            create __init__.py

            create a programs folder
                create an __init__.py
                create a file called routes.py

            create a services folder
                create an __init__.py
                create a file called routes.py

    The folder (ignoring the UV files) should look something like:

    .venv
    .gitignore
    ...
    app/
        __init__.py             <--- main application code
        programs/
            __init__.py
            routes.py
        services/
            __init__.py
            routes.py

    The main application code goes into __init__.py in the app folder

    Open programs/routes.py

    Run the application (in the terminal) from the root (outside the /app folder) using:

        uv run flask --app app run

        Test:
            http://localhost:5000/programs/socas
            http://localhost:5000/programs/sob

            http://localhost:5000/services/aid
            http://localhost:5000/services/wellness
            
            
            
from flask import Blueprint

programs_bp = Blueprint("programs", __name__, url_prefix="/programs")
# creates endpoints under http://localhost:5000/programs

@programs_bp.route('/socas')
def socas():
    return "School of Computing Programs"

@programs_bp.route('/sob')
def sob():
    return "School of Business Programs"